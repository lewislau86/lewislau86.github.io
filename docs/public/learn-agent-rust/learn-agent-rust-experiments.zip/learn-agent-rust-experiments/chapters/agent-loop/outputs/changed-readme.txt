场景：changed-readme；模型：固定规则的脚本模型
预算：model_turns=3 tool_calls=2
消息 1 | user | 读取 README.md，告诉我如何启动项目。
消息 2 | assistant | call_id=read-1 read_file(path="README.md")
消息 3 | tool | call_id=read-1 status=ok | # 课程练习项目 / 启动命令：cargo run --release
消息 4 | assistant | README 里的启动命令是：cargo run --release
统计：model_turns=2 tool_calls=1 read_attempts=1 read_successes=1 messages=4
停止：FinalAnswer；fixture_goal_met=true
