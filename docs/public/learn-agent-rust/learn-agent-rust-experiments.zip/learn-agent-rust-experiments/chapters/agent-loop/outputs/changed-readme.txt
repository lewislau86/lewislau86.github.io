场景：changed-readme；模型：RuleLlm（按规则读取请求内容的脚本模型）
预算：model_calls=不限 tool_calls=不限；循环上限：默认 100
[assistant] call    id=read-1 read_file {"path":"README.md"}
[assistant] result  id=read-1 read_file status=ok {"text":"# 课程练习项目\n启动命令：cargo run --release\n"}
[assistant] text    "README 里的启动命令是：cargo run --release"
[assistant] final
request 0: roles=system,user tools=[read_file]
request 1: roles=system,user,model,function tools=[read_file]
统计：model_calls=2 tool_results=1 read_attempts=1 read_successes=1 session_events=4
停止：final_answer；fixture_goal_met=true
