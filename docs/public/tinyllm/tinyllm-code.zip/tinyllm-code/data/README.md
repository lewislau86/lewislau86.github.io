# TinyLLM 统一唐诗语料

`tang-poems.jsonl` 是 TinyLLM 教程从第 12 章起统一使用的训练语料：17,439 首五言绝句和五言律诗，约 75 万字。处理好的文件直接放在这里，读者不需要自己下载和清洗源数据。

| 项目 | 内容 |
| --- | --- |
| 文件 | `tang-poems.jsonl`，4,355,257 字节，UTF-8，LF 换行 |
| SHA-256 | `764f0614663c20e95927c6ecb63e454629f6cb0efefe9ac84454e256f7173fb1` |
| 规模 | 17,439 首，750,384 字；前 600 首约 2.5 万字、2,505 个不同的字；全部约 5,700 个不同的字 |
| 划分 | 训练 15,758 首、验证 852 首、测试 829 首（按正文哈希固定划分） |
| 来源 | [chinese-poetry](https://github.com/chinese-poetry/chinese-poetry)（MIT 许可证）固定版本 `b8594f81`：《全唐诗》《唐诗三百首》 |

网站下载地址：<https://lewislau86.github.io/tinyllm/data/tang-poems.jsonl>；版本信息见同目录的 `manifest.json`。

## 每一行是什么

```json
{"id": 0, "split": "train", "text": "床前明月光，疑是地上霜。举头望明月，低头思故乡。", "title": "", "author": "", "source": "第 1 章（通行版本）"}
```

- `id`：排序位置，从 0 开始。
- `split`：`train`、`val` 或 `test`。
- `text`：正文，只含汉字和“，”“。”，每句五个字。
- `title`、`author`：题目和作者（简体）；前 39 首为空。
- `source`：`第 1 章（通行版本）`、`唐诗三百首` 或 `全唐诗`。

## 顺序和“前 N 首”

1. 前 39 首就是第 1 章的 39 首，用通行的教材版本（源数据里不少是异文、异体字，例如“床前看月光”“万迳人踪灭”）。
2. 接着 99 首来自《唐诗三百首》的五言绝句和五言律诗。
3. 其余 17,301 首来自《全唐诗》，按固定随机种子打乱。

所以任何一章说“前 N 首”，都是同一份稳定的子集。验证集、测试集按正文的 SHA-256 划分，和顺序无关：取前 600 首，其中约 5% 自动落在验证集；前 39 首全部在训练集。

同一首诗的异文版本（首句、末句都相同，或与前 39 首有两句以上相同）只保留一份，避免同一首诗同时出现在训练集和验证集里。源数据仍有少量异体字和传抄差异，没有逐首校对。

## 章节脚本怎样读它

章节脚本里有一段 `# region corpus` 的 `load_poems(n)`：先找环境变量 `TINYLLM_DATA`、当前目录、`../data/`（整包下载解压后的位置），都没有就从网站下载一份，并核对 SHA-256。在 Windows 上 git 可能把文件检出成 CRLF，`load_poems` 和检查脚本都会先统一成 LF 再核对；仓库的 `.gitattributes` 也让这个文件保持原样。

## 重新生成

```sh
python -m pip install opencc-python-reimplemented
python scripts/prepare-tinyllm-corpus.py
```

脚本会下载固定版本的源数据（约 24 MB，缓存在 `.cache/`），繁体转简体、筛选、去重、排序、划分，结果逐字节可复现。

## 更大的语料

第 13 章“TinyLLM 在 GPU 上完整实现”另用一份唐宋诗大语料（约 29.7 万首、1,726 万字、90 MB），太大不放进仓库，由 `scripts/prepare-tinyllm-large-corpus.py` 在本机生成，校验值见同目录的 `manifest-large.json`。
